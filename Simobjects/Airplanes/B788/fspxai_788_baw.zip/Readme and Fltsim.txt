=========================
http://atco-repaints.com/
=========================
=========================
MS FSX/P3D REPAINT FOR AI
=========================

FS9 NOTE
========
No support is provided by me for FS9

======
BASICS
======
Texture is provided for use with the following AI model
FSPXAI BOEING 787-8

Texture is in native FSX/P3D DDS DXT5 format


============
AIRCRAFT.CFG
============
You will need to add this in sequence to your Aircraft.cfg file

// Requires FSP Boeing 787-8 RR model

[fltsim.x]
title=FSP Boeing 787-8 RR British Airways
sim=FSPXAI_B788v1
model=RR
texture=British Airways
atc_airline=Speedbird
atc_heavy=1
ui_manufacturer=FSPainter
ui_type=Boeing 787-8
ui_variation=British Airways
description=FSPainter Boeing 787-8
atc_parking_codes=BAW
atc_parking_types=GATE



=================
LEGAL MUMBO JUMBO
=================
Copyright Garry Lewis 2018. All rights reserved
Model and Paintkit copyright Missi/FSPXAI

Not authorised by or affliated in any way with the airline or aircraft manufacturer referred to or displayed on included textures.
All copyrights remain theirs.

Authorised only for upload to:
atco-repaints.com
juergenbaumbusch.de
flyingcarpet75.com
jcai.dk
fsxaibureau.com


=======
SUPPORT
=======
For FSX and P3D versions only

http://atco-repaints.com/
