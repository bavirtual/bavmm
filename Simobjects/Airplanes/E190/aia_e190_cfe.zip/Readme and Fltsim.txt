=========================
http://atco-repaints.com/
=========================

=======================
LM P3DV4 REPAINT FOR AI
=======================

FS9 AND FSX NOTE
================
No support is provided by me for FS9.

I exclusively use P3DV4 and beyond now, my textures are
optimised for use on that platform and may have issues
displaying in FSX or older platforms.
Almost all textures will likely still work, this is just
a disclaimer that I don't use FSX anymore and cannot test
compatibility, so no guarantees!


======
BASICS
======
Texture is provided for use with the following AI model
AIAARDVARK EMBRAER E190

Texture is in native P3D DDS DXT5 format


============
AIRCRAFT.CFG
============
You will need to add this in sequence to your Aircraft.cfg file

// Requires AIA Embraer E190 model

[fltsim.0]
title=AIA Embraer E190 BA Cityflyer - To Fly To Serve
sim=aia_emb190
model=
texture=BA Cityflyer
atc_airline=Flyer
ui_manufacturer=Aardvark
ui_type=Embraer E190
ui_variation=BA Cityflyer - To Fly To Serve
description=AIA Embraer E190
atc_parking_codes=CFE,BAWX
atc_parking_types=GATE



=================
LEGAL MUMBO JUMBO
=================
Copyright Garry Lewis 2019. All rights reserved
Model and Paintkit copyright AIAardvark/Mr JB

Not authorised by or affliated in any way with the airline or aircraft manufacturer referred to or displayed on included textures.
All copyrights remain theirs.

Authorised only for upload to:
atco-repaints.com
juergenbaumbusch.de
flyingcarpet75.com
jcai.dk
fsxaibureau.com
Kyle's AI Works


=======
SUPPORT
=======
For P3D version only

http://atco-repaints.com/

Most repaints will work in FSX for now, but can't be guaranteed in future as models become P3DV4 specific and the P3D platform
moves further away from past compatibility
